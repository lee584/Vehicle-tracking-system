package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Vehicle;
import com.service.VehicleService;

@RestController
@RequestMapping("/api/vehicle")
public class VehicleController {
	@Autowired
	private VehicleService vehicleService;
	
	
	@PostMapping
	public Vehicle createVehicleRegistration(@RequestBody Vehicle vehicle) {
		return vehicleService.create(vehicle);
	}
	
	
	@GetMapping("/get-vehicles")
	public List<Vehicle> getAllRegisteredVehicles(){
		return vehicleService.read();
	}
	
	
	@GetMapping("/{id}")
	public Vehicle getRegisteredVehicleById(@PathVariable("id") Integer id)
	{
		return vehicleService.read(id);
	}
	

	@PutMapping("/update")
	public Vehicle updateRegisteredVehicle(@RequestBody Vehicle vehicle)
	{
		return vehicleService.update(vehicle);
	}
		  
}
